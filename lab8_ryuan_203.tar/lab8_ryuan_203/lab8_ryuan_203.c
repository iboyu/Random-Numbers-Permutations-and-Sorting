#include <stdio.h>
#include <stdlib.h>
#define size 50

int *getMemory(int arrayLength)
{
    int *numArray;
    numArray = malloc(sizeof(int) * arrayLength);
    if (numArray == NULL)
    {
        printf("Error allocating memory!\n");
        exit(-1);
    }
    return numArray;
}

void InitArray(int *numArray, int arrayLength)
{
    int i;
    for (i = 0; i < arrayLength; i++)
    {
        numArray[i] = i + 1;
    }
    return;
}

void printArray(int *numArray, int arrayLength)
{
    int i;
    for (i = 0; i < arrayLength; i++)
    {
        printf("%d, ", numArray[i]);
    }
    printf("\n");
    return;
}

void ShuffleArray(int *numArray, int arrayLength)
{
    int randArray[size], i, temp, start;
    for (i = 0; i < arrayLength; i++)
    {
        randArray[i] = rand() % arrayLength;
    }

    start = 0;
    for (i = arrayLength - 1; i > 0; i--)
    {
        temp = numArray[i];
        numArray[i] = numArray[randArray[start]];
        numArray[randArray[start]] = temp;
        start++;
    }
    return;
}

int comp(const void *p1, const void *p2)
{
    int element1 = *(const int *)p1;
    int element2 = *(const int *)p2;

    if (element1 > element2)
        return 1;
    if (element1 < element2)
        return -1;
    return 0;
}

int main(int argc, char **argv)
{

    int seed, numOfElements, *myArray, i;

    if (argc < 2)
    {
        printf("Error. You need to provide more information.\n");
        exit(-1);
    }
    seed = atoi(argv[1]);
    numOfElements = atoi(argv[2]);
    if (numOfElements < 2 || numOfElements > 200)
    {
        printf("Error range.\n");
        exit(-1);
    }

    srand(seed);

    myArray = getMemory(numOfElements);

    for (i = 0; i < 15; i++)
    {
        InitArray(myArray, numOfElements);
        printf("Original list: \n");
        printArray(myArray, numOfElements);
        ShuffleArray(myArray, numOfElements);
        printf("Shuffled list: \n");
        printArray(myArray, numOfElements);
        qsort(myArray, numOfElements, sizeof(int), comp);
        printf("Sorted list after qsort: \n");
        printArray(myArray, numOfElements);
    }

    free(myArray);
    return 0;
}